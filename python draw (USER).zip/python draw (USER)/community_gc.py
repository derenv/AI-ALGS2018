##
# AC21007 Assignment
# 
# Generates graphs made from communities of an input graph
# 
# Created by Deren Vural 2018
# 
##

#imports
import argparse as ap
import os.path as pt
import subprocess as proc

#vars
default_path='./facebook_combined.txt'
community_path='./facebook_combined_communities.txt'
output_designation = 0
i_path=''
o_path=''

#arguement parser setup
parser = ap.ArgumentParser(description='Generates graphs of subset communities of input graph')
parser.add_argument('input_graph_path', metavar='G', type=str, nargs='?', help='the input graph file path', default=default_path)
parser.add_argument('input_community_path', metavar='C', type=str, nargs='?', help='the input community file path', default=community_path)

##
#FUNCTIONS
def sort_and_write(list_obj):
    #if a valid community
    if len(list_obj) > 0:
        #access global community index
        global output_designation
        global o_path
        global i_path
        
        #TEST
        print("COMMUNTITY : "+str(output_designation))
        print("EDGES : "+ str(len(list_obj)))
        
        #get current community from input node list
        sorted_list = facebook_sort(list_obj)

        #name new output community
        file_names = i_path.split('/')
        file_total_name=file_names[-1].split('.')
        o_path = "./"+file_total_name[0]+"_community_"+str(output_designation)+".txt"
        
        #write output community to file
        output = open(o_path, 'w')
        for x in sorted_list:
            output.write(x+'\n')

        #increment community index
        output_designation += 1
    
def facebook_sort(list_obj):
    #create return graph list
    new_list = []
    
    #open facebook graph for finding community
    input_graph = open(i_path,'r')
    
    #if a valid community
    if len(list_obj) > 0:
        #for each edge in facebook file
        for y in input_graph:
            #split line into the two nodes (remove excess carriage returns)
            halves = y.split(' ')
            halves[1] = halves[1].rstrip('\n\r ')
            
            #if both nodes are in the community
            if(halves[0] in list_obj and halves[1] in list_obj):
                new_list.append(halves[0]+"\t"+halves[1])
                
    return new_list

def validate_file():
    #get global variables
    global i_path
    global community_path
    
    #get arguements
    args=parser.parse_args()

    #test if valid input graph path
    print('Input graph file:')
    print(args.input_graph_path)
    if pt.isfile(args.input_graph_path):
        print('..valid file..')

        #get graph
        i_path=args.input_graph_path
    else:
        print('..invalid file..')
        print('..using default facebook data..')

        #get graph
        i_path=default_path

    #test if valid community analysis path
    print('Input community file:')
    print(args.input_community_path)
    if pt.isfile(args.input_community_path):
        print('..valid file..')

        #get graph
        community_path=args.input_community_path
    else:
        print('..invalid file..')
        print('..using default facebook data..')

        #get analysis
        #create output filename
        file_names = i_path.split('/')
        file_total_name=file_names[-1].split('.')
        community_path="./"+file_total_name[0]+"_communities.txt"
        #call community program to produce report
        proc.call(['../community/community','-i:'+i_path,'-o:'+community_path])
##

def main():
    #==validate input==
    validate_file()

    #==manipulate graph==
    #open file
    community_analysis = open(community_path,'r')

    #==load communities==
    #vars
    community_count = 0
    old_community = '0'
    current_community = []

    #for each line in list of communities & nodes
    for x in community_analysis:
        #skip comments
        if(x[0] != '#'):
            halves = x.split('\t')
            #count communities
            if(halves[1] != old_community):
                #increment community count
                community_count += 1

                #get name of current community
                old_community = halves[1]

                #get community and write to file
                sort_and_write(current_community)

                #reset list of nodes in current community
                del current_community[:]
            
            #add to list
            current_community.append(halves[0])

    #test
    print('COMMUNITIES : '+str(community_count))

if __name__=='__main__':
    main()
