##
# AC21007 Assignment
# 
# Visualises an input graph
# colours the communities if specified
# 
# Created by Deren Vural 2018
# 
##

#imports
import networkx as nx
import matplotlib.pyplot as plt
import argparse as ap
import os.path as pt
import sys

#vars
default_path=[]
use_colour=False

#arguement parser setup
parser = ap.ArgumentParser(description='Draw graph in python')
parser.add_argument('input_path', metavar='I', type=str, nargs='+', help='the input graph file path/graph community file paths', default=default_path)
parser.add_argument('-c','--colour', help='display graph with communities coloured', action="store_true")
    
##
#FUNCTIONS
##
def validate_file():
    #access global vars
    global path
    global use_colour

    #get arguements
    args=parser.parse_args()
    
    #test if valid input file
    print('Input file:')
    for ifs in args.input_path:
        print(ifs)
        if pt.isfile(ifs):
            print('..valid file..')

            #get graph
            default_path.append(ifs)
        else:
            print('..invalid file..')
            print('..using default facebook data..')

            #get graph
        #if no input files add 
        if len(default_path) == 0:
                default_path.append('./facebook_combined.txt')

    print("..checking for colour request..")
    #check if the groups should be specified a colour
    if args.colour:
        if len(default_path) == 0:
            use_colour=False
        else:
            use_colour=True
##

def main():
    #validate file paths
    validate_file()

    #visualise graph
    if use_colour:
        #check length of input file list
        if len(default_path) == 1:
            #==========generate communities==========================
            #sys.argv=default_path
            #execfile('./community_gc.py')
            #==========generate communities==========================
            
            #add all generated communities to default paths
            file_names = default_path[0].split('/')
            file_total_name=file_names[-1].split('.')
            string_to_check = file_total_name[0]+"_community_"

            #clear list for resulting communities
            del default_path[:]

            #find all files with 'file_total_name' prefix in directory
            for fname in os.listdir('.'):
                #check is file NOT directory
                if pt.isfile(fname):
                    #if contains search phrase
                    if string_to_check in fname:
                        #add to list
                        default_path.append("./"+fname)

        print("PRINTING WHOLE GRAPH : ")
        #visualise all groups
        colours = ["#5072A7", "#7A332f", "#2f347a", "#f902e5", "#07fc1b", "#b7fc07", "#020202", "#fafcf7", "#4b4a59", "#255b21", "#8daa8a", "#f894fc", "#85b526", "#b55f26", "#f2731f", "#d6986f", "#349b42"]

        #init colour counter
        counter=0

        #for each community graph
        for gg in default_path:
            #test
            print(gg)

            #create graph
            g0=nx.read_edgelist(gg,create_using=nx.Graph(),nodetype=int)
            sp=nx.spring_layout(g0)
            plt.axis('off')

            #add to drawing with individual colour
            nx.draw_networkx(g0,pos=sp,with_labels=False,node_size=35, node_color=colours[counter])

            #increment counter for colours
            counter += 1

        #show drawing
        plt.show()
    else:
        for gg in default_path:
            print("PRINTING SPECIFIED GRAPH : ")
            print(gg)
            #create graph
            g=nx.read_edgelist(gg,create_using=nx.Graph(),nodetype=int)
            print nx.info(g)
            sp=nx.spring_layout(g)
            plt.axis('off')

            #add to drawing with individual colour
            nx.draw_networkx(g,pos=sp,with_labels=False,node_size=35, node_color="#5072A7")
    
            #show drawing
            plt.show()

if __name__=='__main__':
    main()
