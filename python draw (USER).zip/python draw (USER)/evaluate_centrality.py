##
# AC21007 Assignment
# 
# Evaluates average degree, closeness and betweeness of an input graph
# 
# Created by Deren Vural 2018
# 
##

#imports
import argparse as ap
import os.path as pt
import subprocess as proc

#vars
default_path='./facebook_combined.txt'
i_path=''
o_path=''
whole=False

#arguement parser setup
parser = ap.ArgumentParser(description='Evaluates average degree, closeness and betweeness of an input graph')
parser.add_argument('input_path', metavar='I', type=str, nargs='?', help='the input file path of centrality analysis', default="./test.txt")
parser.add_argument('whole_path', metavar='W', type=str, nargs='?', help='the input file path of whole graph', default="./test.txt")
parser.add_argument('-w', '--whole', help='process whole graph', action="store_true")
    
##
#FUNCTIONS
##
def parse_results():
    global o_path

    #access report
    report_file = open(o_path, 'r')

    #vars
    total_degree=0
    total_closeness=0
    total_betweeness=0
    node_count=0
    
    #parse report
    for l in report_file:
        #skip comments
        if(l[0] != '#'):
            #increment counter
            node_count += 1
            
            #split into values
            halves = l.split('\t')

            #add to total degree
            total_degree += float(halves[1])
            
            #add to total closeness
            total_closeness += float(halves[2])
            
            #add to total betweeness
            total_betweeness += float(halves[3])

    if node_count != 0:
        #calculate averages
        average_degree = total_degree / node_count
        average_closeness = total_closeness / node_count
        average_betweeness = total_betweeness / node_count

        #output to user
        print("Average Node   Degree   Centrality : "+str(average_degree))
        print("Average Node Closeness  Centrality : "+str(average_closeness))
        print("Average Node Betweeness Centrality : "+str(average_betweeness))
    else:
        print("..An invalid input graph has been used..")
        
def validate_file():
    #global variables
    global i_path
    global whole
    
    #get arguements
    args=parser.parse_args()

    #test if valid input file
    print('Input file:')
    print(args.input_path)
    if pt.isfile(args.input_path):
        print('..valid file..')

        #get graph
        i_path=args.input_path
    else:
        print('..invalid file..')
        print('..using default facebook data..')

        #get graph & report
        i_path=default_path
        whole = True
##

def main():
    #global vars
    global o_path
    global i_path
    global whole
    
    #validate input
    validate_file()
    
    #parse output
    if whole:
        print("EVALUATING GRAPH : ")
        print("PRODUCING GRAPH ANALYSIS : ")

        #create output filename
        file_names = i_path.split('/')
        file_total_name=file_names[-1].split('.')
        o_path=file_total_name[0]+"_output.txt"
    
        #call centrality program to produce report
        proc.call(['../centrality/centrality','-i:'+i_path,'-o:'+o_path])
    
        if pt.isfile(o_path):
            #parse the analysis results
            parse_results()
        else:
            #error message
            print("\n..report generation failure..")
    
    else:
        print("EVALUATING GRAPH ANALYSIS REPORT : ")

        #parse the analysis results
        parse_results()

if __name__=='__main__':
    main()
