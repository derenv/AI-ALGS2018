###############################
# AC21007 Assignment
# 
# All of the following programs
# written in Python 3 require
# the Stanford SNAP C++ library.
# 
# Deren Vural 2018
#####pydraw.py#################
#
# Visualises an input graph
# colours the communities if
# specified
#
# When passing the colour option,
# if only one graph is passed the
# program looks for the results of
# the 'community_gc.py' program on
# that graph and displays them.
# Otherwise, the program will display
# all the passed graphs together in
# different colours.
# 
# Created by Deren Vural 2018
# 
# usage: pydrawu.py [-h] [-c] I [I ...]
# 
# Draw graph in python
# 
# positional arguments:
#   I             the input graph file path/graph community file paths
#
# optional arguments:
#   -h, --help    show this help message and exit
#   -c, --colour  display graph with communities coloured
# 
#####community_gc.py###########
#
# Generates graphs made from
# communities of an input graph
# 
# Created by Deren Vural 2018
# 
# usage: community_gc.py [-h] [G] [C]
# 
# Generates graphs of subset communities of input graph
# 
# positional arguments:
#   G           the input graph file path
#   C           the input community file path
# 
# optional arguments:
#   -h, --help  show this help message and exit
# 
#####evaluate_centrality.py####
#
# Evaluates average degree,
# closeness and betweeness of
# an input graph
# 
# Created by Deren Vural 2018
# 
# usage: evaluate_centrality.py [-h] [-w] [I] [W]
# 
# Evaluates average degree, closeness and betweeness of an input graph
# 
# positional arguments:
#   I            the input file path of centrality analysis
#   W            the input file path of whole graph
# 
# optional arguments:
#   -h, --help   show this help message and exit
#   -w, --whole  process whole graph
# 
###############################
